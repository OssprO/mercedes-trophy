<?php
/**
 * @package WordPress
 * @subpackage Mercedes Trophy
 * @since Mercedes Trophy 1.0
 */
 get_header(); ?>

	<h2><?php _e('Error 404 - Page Not Found','mercedestrophy'); ?></h2>

<?php get_sidebar(); ?>

<?php get_footer(); ?>